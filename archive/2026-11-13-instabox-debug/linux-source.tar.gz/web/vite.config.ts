import { defineConfig } from "vitest/config";
import vue from "@vitejs/plugin-vue";
export default defineConfig({
  plugins: [vue()],
  test: { environment: "jsdom", restoreMocks: true },
  build: { target: "es2022" },
});
