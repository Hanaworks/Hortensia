# Agent 模块设计

更新日期：2026-11-07。状态：整体仍为M1内部设计与v1执行工作规格，通信、开始账本、事件／首结果及[本地恢复扫描](../specifications/m0-agent-scan.md)的受控切片已完成；2026-11-12又完成[v4双端释放](../specifications/m0-dual-release.md)本地验收，尚无真实执行的完整Agent；扫描完成边界与证据见[验收记录](../implementation/m0-agent-scan.md)。本文展开[整体架构](../architecture.md)中的节点侧构件，供节点执行与协议实现者使用，承接R02、R04—R10、R12、R13、R15及Q03、Q04、Q06—Q10。Agent主动接入已确认；具体报文由[Agent协议](../specifications/agent-protocol.md)维护，必要执行与恢复细节由[执行规格](../specifications/execution-recovery.md)承接，各原型范围见相应实施记录。

## 1. 内部组成

| 部分 | 责任、输入与输出 | 依赖 |
| --- | --- | --- |
| 身份与连接 | 读取节点身份、验证管理端、协商协议和能力、维护会话、重连 | 本地身份材料、Manager 可达路径 |
| 任务收件与账本 | 接收指定节点任务、比较标识摘要、保存阶段与结果、重报 | 本地持久化、认证通道 |
| 执行调度 | 资源互斥、准备完成后请求开始许可、取消边界和进程监督 | 账本、工作区和执行适配器 |
| 配置工作区 | 校验内容、物化相对文件关系、维护版本和执行输入 | 受管理根目录、文件元数据 |
| Compose 适配 | 原生校验、部署与生命周期，固定程序和参数执行 | 工作区、CLI、实际 Docker 端点 |
| Docker 资源适配 | 查询和操作容器、镜像、网络、卷 | 获准的 Docker 连接和能力 |
| 诊断会话 | 日志、统计和控制台的建立、限界和关闭 | 资源适配、当前会话授权 |

运行依赖为：连接接收任务 → 账本登记 → 工作区准备／能力检查 → 调度获取开始许可 → 执行适配器 → 账本保存结果 → 连接重报。查询和观察也带节点、对象和时间，不通过查询路径接受任意 shell 命令。

## 2. 启动、身份与能力

先读取已有身份及账本，检查工作区可用性和实际 Docker／Compose 能力，再连接 Manager。首次接入材料仅用于认领，长期身份的存储、撤销与轮换由 O03 规定。重装 Agent 不得通过同名节点自动取得原节点执行权。

报告 Agent 版本、协议能力、Docker 端点可用性、Compose 版本和相关执行能力；连接成功不等于能部署。协议不兼容可拒绝变更并说明原因。失联期间不接受新未授权操作，重连先核对旧任务再恢复新变更。

## 3. 工作区与配置输入

工作区按节点内稳定 Stack 标识和配置版本组织；具体磁盘目录在交付设计中确定。每次任务保存原文文件、有序主文件列表、环境输入、项目名称和目标 Docker 端点引用。执行引用任务固定输入，不在运行中读取“最新配置”。

1. 验证包内路径与名称，禁止绝对路径、目录穿越和通过符号链接越出受管理根；如以后允许归档导入，解包同样检查。
2. 在受管理目录内物化文件，保持引用关系，完成校验后发布可执行版本；内容摘要不符时拒绝使用。
3. 明确 Compose 的工作目录及变量来源。环境文件插值、容器 env_file 和 Agent 进程环境分别处理，不意外继承服务进程中的秘密。
4. 调用实际 CLI 校验输入和能力。未知引用组合、缺文件、构建依赖或不能满足的路径不静默改写。

包内相对路径安全检查只限制管理器主动读写的文件，不是对获准 Compose 的主机权限隔离。例如用户明确声明的主机绑定目录作为应用依赖处理，不自动复制到配置包，不假称必定位于工作区。

Agent 所在文件系统与 Docker Engine 所在文件系统可能不同。Compose 自己读取的文件、Engine 解析的绑定路径、配置资源的消费者必须逐类确认。无法验证这种关系时报告不支持，不能把远程端点当作同机等价；兼容组合在 O04 验证。

工作区被外部修改时回报漂移，不能使用未知内容执行。管理器的文件清理只能处理不被活动部署或未结束操作引用的内容；配置目录可能被声明为运行挂载来源，因此不能仅凭任务结束就删除目录。

## 4. 执行账本和去重

任务由 operation_id、node_id、输入摘要、操作类型和目标共同识别。收到相同标识同摘要时返回已有准备、执行或结果状态；摘要不同则拒绝。账本先持久记录准备事实，再请求开始；收到有效许可后记录开始事实，再创建底层进程。

这些记录只能减少可控制范围内的重复执行，不能把账本写入和 Docker 副作用组成一个分布式事务。开始记录后崩溃、进程创建后失联、账本损坏等情形都可能需要核对。M1 建议使用本地 SQLite WAL／FULL，开始请求采用 10 秒本地窗口并绑定当前连接，详见第 9 节及[接口规格](../api-design.md)；这些机制仍需 O02／O03 验证。

执行互斥以目标集合为依据，防止同时修改同一个项目或资源。执行中的未知任务不因重连自动释放互斥。端口和外部资源冲突仍可能来自管理器以外，预检只提供当时观察，底层错误必须保留。

## 5. Compose 与资源执行

采用固定可执行程序和参数数组，不使用 shell 拼接配置、名称或 run 输入。部署显式关闭 Build，并按所选版本验证该约束；保留 build 原文，若没有可用镜像则提示不能部署。文件顺序、项目名称和目录规则继续使用 Compose 原生语义，不能自行合并 YAML 后替代原始输入。

捕获退出码、输出的受控记录、开始结束时间和受影响对象；执行后另采集资源观察。命令退出成功只支持命令层结论，不自动生成业务健康证明。删除数据是独立的明确动作，不把卷清理暗含在一般移除中。

容器、镜像、网络、卷的适配器调用实际 Docker 能力，检查目标标识和归属。资源不存在时区分“已达到删除结果”和“目标可能被替换”，不能用名称匹配删除新的同名对象。查询关联不完整时标注未知。

## 6. 取消、断线和重启

| 情形 | 处理和证据 |
| --- | --- |
| 尚未开始收到取消 | 已有准备记录时持久保存 not_started/canceled_before_start 结果，禁止启动；无记录返回 operation_not_found，待 Manager 扫描核对 |
| 已开始收到取消 | 记录请求并按执行器可用方式尝试终止；不宣称已回滚，采集资源后决定结果或进入核对 |
| Manager 失联 | 已开始操作保留本地记录，按执行策略完成或停止；不开始依赖新许可的后续阶段 |
| 结果回报未确认 | 保留结果并重报同一 operation_id，不重新执行 |
| Agent 重启 | 加载未终结账本，核对受监督进程和资源；不能由 PID 相同或进程不存在推定结果 |
| 账本丢失／内容不符 | 停止相关自动变更，报告 reconciliation_required，由 Manager 组织核对 |

M1 的 Linux 进程组、取消和服务退出建议见第 9.4 节，其他运行组合必须另行验证。浏览器关闭只结束展示或会话，不等于取消节点任务。

## 7. 诊断流和敏感信息

诊断会话绑定节点、资源、用户授权范围及会话标识；只接收结构化控制台参数，不提供管理端任意系统命令入口。断线、撤权、资源退出和会话关闭都需释放流与终端资源。日志或应用自己输出的秘密无法保证被通用规则完全过滤，应限制访问；系统自己生成的调试输出不得无必要地打印凭据或完整环境。

## 8. 工程承接与检查

接入接口见[接口规格](../api-design.md)，账本与观察对象见[数据设计](../data-design.md)。第 9 节提出程序内部边界、生命周期和输入范围，具体库与运行版本经原型锁定。首个端到端切片不能只有网络可连，必须验证真实 Compose 输入和故障恢复。

关键用例包括包路径越界、环境污染、无意构建、任务重复、执行中断线、许可后重启、结果重报和账本丢失，对应 T04、T07、T08、T13、T17。结构持续采用 [arc42 构件](https://docs.arc42.org/section-5/)、[运行](https://docs.arc42.org/section-6/)和[部署](https://docs.arc42.org/section-7/)；生命周期写法的辅助来源见[文档规划](../documentation-plan.md)。

## 9. M1 执行方案

本节落实 P07—P10，范围是 Linux 上的 Agent、原生 Docker CLI／Compose 插件与同机 Unix socket。它是首轮验证组合，不取消其他 Unix-like 环境需求，也不证明 FreeBSD 或远程 Docker 已兼容。Agent 作为具有 Docker 操作权限的可信服务账号运行；工作目录只允许该账号访问，访问 Docker 通常意味着较高的宿主机权限，不能据此提供不可信租户隔离。

### 9.1 启动、目录与任务入口

建议身份文件为 `/etc/docker-manager-agent/identity.json`，账本为 `/var/lib/docker-manager-agent/agent.db`，工作区位于同一状态根的 `workspaces/`。身份、指纹密钥、账本和工作区是一套节点执行状态；重装时不能只保留显示名称就恢复执行资格。

启动先取得状态根的操作系统排他锁，再读取身份与账本，确认密钥匹配、数据库可写及必要磁盘空间。锁贯穿进程生命周期；第二个实例立即退出，不争抢同一节点。首次认领前，Agent 在本机生成并耐久保存随机候选凭据，再用一次性接入材料向 Manager 登记；响应丢失先用候选凭据验证连接，不重复创建身份。[接口规格](../api-design.md)维护认领、轮换与报文定义。

每次启动生成新的 `boot_id`，账本有持续的 `ledger_id`。连接模块只能在身份、能力与恢复核对完成后把通道交给调度器；重连后的新 `session_id` 不使旧许可重新有效。身份匹配但账本丢失、旧许可存在或进程结局不明时，先报告待核对，相关资源不接收新变更。

接收 Prepare 时，先核对节点、协议、消息大小及操作类别，再比较 `input_digest` 与本机 `local_fingerprint`。前者是 Manager 生成的不透明 HMAC 标识，后者以本地私有密钥对收到的冻结 payload 字节计算，不向普通查询公开。相同操作的任一值不同均拒绝；账本和私有密钥的具体保存规则见[数据设计](../data-design.md)。

### 9.2 配置包和外部依赖支持矩阵

文件包传递原始字节，M1 编辑能力仅接受 UTF-8 文本；不转换换行、不重写 YAML，也不读取 Agent 环境代填内容。候选上限为单文件 1 MiB、文件内容合计 4 MiB、128 个文件；整个消息含编码后不得超过接口篇的 8 MiB。超限可以保存前给出明确错误，不能截断后继续部署。这些值是待验证的工程预算，不是用户确认的容量目标。

| 输入 | M1 建议支持 | 拒绝或约束 |
| --- | --- | --- |
| 主文件 | 包内一个或多个 Compose 文件，按提交顺序重复传 `-f` | 列表为空、路径不存在、重复或越界拒绝 |
| 包路径 | 相对 POSIX 路径，保留大小写；文件父目录由 Agent 创建 | 拒绝绝对路径、盘符、反斜杠、空片段、`.`／`..`、NUL、重复路径和符号链接；不接受可自行解包的 tar／zip |
| 环境 | 明确的插值变量映射和有序 `--env-file`；包内 service `env_file` 字符串／字符串列表 | 不继承服务进程环境；v1 部署拒绝 env_file 映射扩展；读取路径含插值时明确报不支持，普通变量值仍原生插值 |
| 附属文件 | 包内普通配置、file 形式的 configs／secrets、字面量 label_file、相对只读绑定文件 | 文件读取引用必须在包内；不读取任意绝对路径秘密；configs／secrets 其他来源形式本版不支持 |
| 原生项目资源 | 由 Compose 声明的网络、卷、端口、profiles、镜像与服务 | 不注入额外资源；外部命名网络／卷需目标预先存在，绑定目录视为外部依赖 |
| 应用数据挂载 | 显式绝对宿主机绑定路径；使用包内相对文件作为配置挂载 | 路径不随 Copy 搬运；相对可写数据目录、包内内容被应用写回的挂载在 M1 拒绝，避免破坏不可变版本 |
| 外部引用与扩展 | 原文可保存以供编辑；标准 YAML anchor／alias／mapping merge 可预检 | v1 部署拒绝 include、extends、远程引用、credential_spec、provider、develop、models、生命周期 hook、自定义 tag；完整范围见执行规格，不改写为“兼容” |
| build 与镜像 | 原文保留 build；可执行的服务必须有明确 image，并使用 `--no-build` | 不上传上下文、不运行 build；缺镜像且无法按原生策略取得时失败，不自动补建 |
| Docker 连接 | 服务配置指定的同机 Unix socket | Compose 内容、Web 输入不能改变 Docker host／context；远程端点在 M1 报未支持 |

静态预检先展开单文件 YAML alias 和 mapping merge，按已知引用位置检查所有提交的 Compose 文件，再调用原生 config 合并和插值；渲染后检查挂载、外部资源及归属。为避免自行复制 Compose 插值引擎，v1 对文件读取路径和挂载来源含插值的部署明确报不支持，保留原文保存能力。[执行规格第 2 节](../specifications/execution-recovery.md#2-配置预检与原生执行)列出顺序、读文件位置和错误，作为本轮比上一版更明确的支持边界。绑定挂载允许的宿主机路径是应用授权范围，不受包目录限制，也不代表管理器已备份其中数据。

每个版本在 `workspaces/{stack_id}/{version_id}/package/` 物化；先写临时目录、校验并耐久发布，再将账本标为 ready。目录与文件分别采用服务账号私有权限，按固定版本核对本地指纹；已有目录内容变化则拒绝复用。部署任务再冻结其工作目录、端点与环境。运行挂载可能引用旧版本目录，M1 不自动删除这些目录。

### 9.3 原生校验、环境和参数数组

执行器使用绝对路径的 Docker 程序及参数数组。共同前缀建议为：`--host <本地socket> compose --ansi never --project-name <固定项目名> --project-directory <package绝对目录>`，随后依次加 `--env-file <文件>`、`-f <文件>` 和 `--profile <值>`。所有值为单独参数，不通过 shell 再解析。文件、工作目录、环境及全局参数在校验与 Apply 中完全一致。[Docker Compose 全局参数](https://docs.docker.com/reference/cli/docker/compose/)

子进程环境从空集合构造：仅加入服务配置允许的 PATH、独立 HOME／DOCKER_CONFIG、固定 locale 及显式插值变量。`DOCKER_*`、`COMPOSE_*`、PATH、HOME 等执行控制键不得由普通插值输入覆盖；拒绝冲突并指出字段。插值显式变量优先于 env 文件，遵循原生优先级；多个 env 文件顺序固定。若用户未指定 env 文件，包内 `.env` 存在时显式选择它，否则使用工作区外的受控空 env 文件，避免读取机器上的隐含环境文件。[原生插值来源](https://docs.docker.com/compose/how-tos/environment-variables/variable-interpolation/)

准备阶段调用 `config --format json`，只在内存解析并检查支持范围、有效镜像、外部依赖及项目冲突，不保存或普通日志打印含秘密的渲染正文。必要的秘密诊断也通过受限输出处理。原生校验本身不代表部署成功。[config 命令](https://docs.docker.com/reference/cli/docker/compose/config/)

获得开始许可后复核固定工作区、执行配置和目标基线，再调用同一前缀加 `up --detach --no-build`；不隐式增加 `--remove-orphans`、`--force-recreate`、`--pull always` 或删除卷选项。`pull_policy: build` 拒绝，其他镜像策略继续由配置和原生行为决定。M1 新项目遇节点既有同名项目时拒绝；受管理项目使用节点本地 project_bindings 及部署前后基线核对漂移和自身合法重建，具体见[归属规则](../specifications/execution-recovery.md#3-资源归属与合法替换)。不能把仅有相同 label 的外部项目自动接管。[up 命令](https://docs.docker.com/reference/cli/docker/compose/up/)

退出后单独采集该项目资源，以操作实际输入记录版本。配置版本固定不等于镜像标签永不变化：需要可重现镜像时使用用户明确给出的 digest，系统记录实际 image ID，不静默改写标签。没有 healthcheck 的服务显示“未声明健康检查”，不能显示“业务健康已验证”。

### 9.4 开始、取消和进程生命周期

调度器为每个操作串行处理 prepare、authorize_start 和 cancel。request_start 生成一次性 nonce，记录本地单调时间；只接受当前连接、同 nonce、同输入且 10 秒内的许可。收到有效许可时，在同一执行互斥中再次检查取消标志并持久提交 `START_COMMITTED`，提交后、启动前再检查连接和期限；失效则不创建进程，持久报告实际未启动证据，无法持久确认时转核对。提交失败不能执行；提交成功但尚未启动就崩溃时也不能自动重做，必须进入核对。Manager 以授权事务提交区分先后，Agent 不承诺撤回已经开始的操作。

Linux 执行器为命令建立独立进程组，持续读取 stdout／stderr，及时回收子进程。两个管道按采集器接收顺序合为一个流，不承诺重建它们在进程内的绝对先后；使用增量 UTF-8 解码器，以 U+FFFD 替换非法序列，防止跨读取块截断合法多字节字符。每操作持久采集上限为转换后 1 MiB UTF-8 字节，不截半个字符；output_b64 传输这些固定字节，HTTP 输出游标也基于同一流。达到上限仍继续排空原始管道并标记截断。输出可能含秘密，按 `operation.output.read` 控制并加密持久化，不混入普通服务日志。Go 的 [os/exec](https://pkg.go.dev/os/exec)提供进程与管道能力，但不会自动实现这里的进程组和取消策略。

开始前取消由账本持久标记后确认无副作用；开始后的取消先记录请求，再对已知的本次进程组发 SIGTERM，候选等待 10 秒后仍存活则 SIGKILL，最后读取退出状态并观察资源。即使退出码为 0，也不能仅据此报告取消已回滚。无法确认进程退出或 Docker 影响时保持 reconciliation_required。M1 候选执行期限为 30 分钟，超时采用同一中断及核对路径；期限可由运维配置，在原型中用慢镜像和失联验证，不作为性能承诺。

普通 Manager 断线不终止已开始的本地命令；Agent 保存结局待重连上报，停止需要新许可的操作。Agent 收到服务终止信号时停止接收新变更、使未消费许可失效、对活动进程采用上述终止与核对过程。服务管理器必须给足终止宽限并回收残留进程；强制杀死、系统重启或 PID 复用后，不凭 PID 找到或消失就认定结果。M1 不自动接管残留进程继续执行，相关项目先保持核对占用。

### 9.5 工程边界与验证输出

建议在 `internal/agent/` 内按 `identity`、`channel`、`ledger`、`workspace`、`executor`、`compose` 分包。channel 不能绕过 ledger 调用 executor；executor 只接收已冻结的结构化输入；workspace 不负责生成业务配置。目前 `ledger` 已按[开始账本规格](../specifications/m0-agent-ledger.md)、[事件日志规格](../specifications/m0-agent-journal.md)和[扫描规格](../specifications/m0-agent-scan.md)落实受控SQLite子集，其余目录仍为工程建议。该子集包含准备夹具、开始事实、占用、加密首结果、单操作恢复读取及本地全账本扫描／完成回执，尚不能处理真实部署。

M0 至少输出：同一输入的原生对照、路径拒绝清单、10 秒许可迟到及撤权竞争、START_COMMITTED 前后崩溃、命令超时和残留进程、结果丢包与账本丢失证据。首次得到成功部署不代表这些故障边界已经验证。

## 10. 结果与释放接入

2026-11-07的[事件日志切片](../implementation/m0-agent-journal.md)已落实started与开始事实原子提交、首份受控result加密保存、确认及单操作RecoveryRecord读取。其v2新库不隐式升级v1，调用方仍须提供真实执行／归属证据和网络关联；下面补观察及finalize目标机制尚未实现，不能因能读取结果而释放占用。

结果的 outcome 区分 not_started、normal_exit、interrupted、unknown；ownership_status 区分 not_checked、consistent、drifted、unknown。正常退出只有在观察 complete 且归属 consistent 时才可自动终结；不能只用 exit_code 判定是否可释放。正常退出但观察失败、尚无明确漂移时，接收绑定原 operation_id 的只读补观察，保留原进程事实，以新 event_seq 发布新观察及重新核对的 ownership_status，不执行第二次 Compose。观察完整但归属 drifted／unknown 仍保持核对。

ack 只确认 Manager 已保存事件。Agent 必须等收到绑定同一结果的 finalize，事务内保存 finalized 并释放 local_claims，随后回报；重复 finalize 读取既有释放回执。Manager 保留自己的占用直至 finalized。完整判定矩阵、两端提交顺序和未知时的人工维护限制见[执行与恢复规格第 5、6 节](../specifications/execution-recovery.md#5-恢复判定与占用释放)。未知执行仍保持隔离，当前没有可用的通用强制解锁工具。

## 11. 内外对象衔接与接手维护

本节于2026-11-07补充，串联前述设计及已经实现的独立子模块。第11.1节说明M1目标处理关系，第11.2节明确M0已经具备的接线，不能把两者合并成现有端到端流程。协议字段仍以[Schema](../../contracts/agent-v1.schema.json)和[Agent协议](../specifications/agent-protocol.md)为唯一主定义。

### 11.1 输入如何成为本地执行材料

Agent 对外接收受认证的结构化任务，内部把它分成固定输入、准备材料、许可窗口、执行证据四类。连接身份、原文字节、派生模型和本地资源不能因名字接近就互相替代。

| 输入／内部材料 | 负责的消化处理 | 生命周期与输出约束 |
| --- | --- | --- |
| prepare 信封、外层目标与 `payload_b64` | 通道绑定当前节点／session；协议校验解码 `FrozenPayload`，核对内外 node／stack／version、能力和预算；账本比较 Manager 摘要和本地指纹 | `payload_bytes` 保留收到的原字节用于指纹，不能先重新序列化。传输 message_id 可变，operation_id 和固定输入不可变 |
| `Config.files` 及有序引用 | 工作区将 `content_b64` 解码成原文，按包内相对路径物化；Compose 适配器校验读取入口，再用原生 config 生成仅供检查的模型 | 原文版本目录供实际 CLI 和运行挂载使用；规范化模型只存在于准备处理，不能替换用户原文或成为普通日志 |
| 项目名、`execution_profile`、固定工作区与环境 | 调度器取得本机已配置端点和策略修订，与冻结值比较；适配器形成第9.3节的程序、参数数组、工作目录和环境 | 这是建议内部执行上下文，不新增线上字段。执行器不重新读“最新版本”，也不接受 Web 提供的任意命令或 Docker host |
| 预检所得资源与 `project_bindings` | 资源适配器取得实际 ID／逻辑键；归属处理把 pre/post 观察与已登记基线比较 | 普通查询不更新 active 基线；合法自身重建与外部替换依[归属规则](../specifications/execution-recovery.md#3-资源归属与合法替换)区分，在finalize事务中与结果关联提交新active基线；普通result的ack不执行此更新 |
| request_start 的 nonce 与收到的许可 | 调度器维护当前连接的一次窗口；账本事务保存许可和开始事实；执行器只在提交成功并再次检查后启动 | 单调时限只在本次进程有效，数据库 UTC 时间不用于重建许可。START_COMMITTED 是可能执行的边界，不是进程创建回执 |
| 进程监督结局、固定输出流及事后观察 | 执行器给出真实正常退出／中断／未知事实；观察与归属处理给出独立证据；账本保存 result | 原始结果按敏感正文保护；normal_exit 不自动等于可释放，health 状态不自动等于业务验证 |
| 账本事件与确认 | 通道从持久 body 构造当前连接的新信封；经关联验证后的 ack 交账本保存 | 重报仅改变信封，不重做 CLI、不改旧 body。结果保留与占用释放是两件事，finalize 的实现仍缺失 |

例如一次更新将容器 ID A 合法重建为 B：执行前归属基线和本次操作输入确定 A 对应的服务，正常退出后检查 B 的预期逻辑键及替换证据，再把候选新基线和结果关联。不能让下一次普通容器列表把 B 自动写成受管理基线；否则外部同名替换也会被掩盖。相关字段和算法集中维护于执行规格，Agent 模块负责确保准备、执行、观察、账本都使用同一个操作上下文。

### 11.2 当前子模块的实际协作与未接线处

当前网络路径是 `channelprobe → channel → protocol`，只做握手、探活及冻结诊断。另一条受控路径是测试调用 `ledger.RecordReadyFixture → ledger.NewGate → startgate.Authorize → 持久提交 → Start回调`；v2／v3随后允许 `RecordResultFixture` 保存首结果。v3另有 `CreateRecovery／OpenRecovery → BindRecoverySessionFixture → Reconcile → CompleteReconcile` 的本地扫描路径，初次扫描完成后才允许新的准备与开始；扫描期间已有执行仍可保存结果，变化须由当前会话确认。这些账本路径尚未与网络接通，函数名中的 Fixture 是能力边界，不是正式准备／执行服务的别名。

| 现有模块输出 | 当前能证明什么 | 后续接入方仍需承担什么 |
| --- | --- | --- |
| `RecordReadyFixture` 的 Record 与两个 Claim | prepare 结构、固定身份／摘要、同操作去重和占用已登记 | 工作区物化、原生预检、能力与实际连接验证；当前函数不执行这些动作，不能用于真实部署处理器 |
| `NewGate` 及其 Start 回调 | 本boot的一次门禁；回调前开始事实已提交；v2／v3同时有started事件；v3扫描冻结阻止新开始 | 当前连接失效时调用Invalidate，真正取消调用Cancel，提供单调时钟和短Start回调；数据库context取消不能代替业务取消 |
| `RecordResultFixture` 的 Event | 提供的首结果满足结构及账本前提，原body加密持久保存 | 证明真实进程结局、资源观察及归属；存储模块不会测得这些事实，也尚不接受补观察的新result版本 |
| `PendingEvents`／`ReadEvent`／`AcknowledgeEvent` | 可重读原body，按连接判断是否待确认，持久记录逐事件确认；v3确认事务复核当前绑定session／boot | 认证连接、方向、reply_to与事件的网络关联检查，发送重试和队列预算；调用确认函数本身不是线上ack验收 |
| `RecoveryRecord` | 单一数据库快照中的开始、事件、确认、占用一致，按证据派生协议阶段；作为全账本扫描的内部投影基础 | 业务恢复判定；一次读取不能证明身份枚举完整或释放占用 |
| v3 `Reconcile`／`CompleteReconcile` | 持久冻结、固定成员与有界原文分页、当前会话变化确认、期限与scope替换、持久completed重放；完成不释放claims | 将可信会话接到真实通道并适配错误；Manager持久接收全部页、合并变化、核对旧许可／占用／缺失历史及必要释放，再保存completed并开放新受理 |

`executions.phase` 当前只保存ready或START_COMMITTED；有result、blocked或旧boot未知时，恢复接口按[事件模块阶段映射](../specifications/m0-agent-journal.md#83-数据状态与对外阶段的区别)派生协议phase。Manager的操作state还需要独立判定，不能把某个本地phase字符串复制成用户看到的成功。v1开始账本、v2日志、v3扫描分别使用自己的打开入口和DDL；v3是显式新实验库，没有v1／v2升级工具，开新库不能绕过原节点未知任务。扫描的完整行为和S01—S12证据集中在[扫描规格](../specifications/m0-agent-scan.md)及[验收记录](../implementation/m0-agent-scan.md)，不以本表替代模块定义。

### 11.3 生命周期与故障定位

持久身份与账本、配置工作区、连接／Gate、子进程具有不同寿命。连接重建只换session并失效旧许可；Store重开产生新boot而冻结旧执行资格；工作区可能仍被应用挂载使用；进程退出后仍要保存结局并完成核对。v3在同boot重连时可以保留活动扫描及原期限，重开则因原文缓存丢失拒绝续页并保持冻结；最近completed只可重放回执，不能结束新的冻结。M0已实现Store.Close使Gate失效并等待短Start回调退出后关闭数据库，再清理扫描缓存，但没有生产进程单实例锁、Compose进程监督和工作区清理。完整服务关闭按第9.4节落实，不能把关闭数据库当成已终止Docker副作用。

| 现象／修改范围 | 定位顺序与源码入口 | 必须守住的边界及验证 |
| --- | --- | --- |
| 身份或账本不能打开 | 身份、schema、K_ledger／JournalKey配对；[store.go](../../internal/agent/ledger/store.go)、[journal_store.go](../../internal/agent/ledger/journal_store.go) | 不删库补空身份；表定义以账本／事件规格为准，检查L01—L02、J01 |
| 许可看似有效却没有Start | 原操作boot、占用、prepared_session、Gate期限／取消、开始提交；[gate.go](../../internal/agent/ledger/gate.go)和[startgate](../../internal/startgate/gate.go) | 已提交但未调用Start也保留证据；不能再建Gate，检查L05—L09、J04 |
| 结果保存失败或冲突 | 原事件位置／body、blocked、密钥额度、事务；[results.go](../../internal/agent/ledger/results.go)、[journal_crypto.go](../../internal/agent/ledger/journal_crypto.go) | 原结果不覆盖、额度预留不退款、占用不释放；检查J02—J06 |
| 重开后未知或确认后仍待发送 | 当前boot、最新结果、ack_session、claims；[events.go](../../internal/agent/ledger/events.go)、[recovery.go](../../internal/agent/ledger/recovery.go) | 旧连接确认不代替新连接核对；无结果不伪造退出码；检查J07—J09 |
| 扫描无法续页、不能完成或重连后仍冻结 | 先按[扫描规格的异常与维护说明](../specifications/m0-agent-scan.md#6-异常维护与验证)检查版本／boot／session、active／dirty、变化确认及completed，再查原文缓存与期限 | 过期和重开不解冻；历史completed不结束新扫描；变化确认与完成同事务约束不拆开，验证以[S01—S12](../implementation/m0-agent-scan.md)为准 |
| 修改支持的Compose输入或清理工作区 | 第9.2—9.3节、[预检算法](../specifications/execution-recovery.md#2-配置预检与原生执行)、运行挂载引用 | 先改支持矩阵和验收，再开放能力；需真实原生对照T04／T13／T17，现有账本测试不能证明 |

排障以固定错误码、node／ledger／operation、阶段和事件位置定位，不把密钥、解密body或配置全文放入普通日志。包内完整字段、锁顺序、事务失败与修改规则分别见[开始账本内部说明](../specifications/m0-agent-ledger.md#7-内部实现与维护说明)、[事件日志内部说明](../specifications/m0-agent-journal.md#7-内部结构与职责)和[扫描规格](../specifications/m0-agent-scan.md)；本页保留组件间协作，不复制各表字典。验收证据以[L01—L10](../implementation/m0-agent-ledger.md)、[J01—J10](../implementation/m0-agent-journal.md)和[S01—S12](../implementation/m0-agent-scan.md)为准。2026-11-07本次入口同步反映新增本地扫描切片；验证使用本机临时数据库与辅助进程，无需真实部署环境，未新增真实Compose、Manager完整业务恢复、旧库升级或掉电耐久结论。
