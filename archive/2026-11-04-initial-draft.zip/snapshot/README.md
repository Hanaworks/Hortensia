# Docker Manager

自托管的多节点 Docker 管理器，面向维护多台独立节点的运维人员。节点管理与迁移体验参考 PVE，Docker 资源及 Compose 操作参考 Portainer；由用户明确决定部署位置，以 Node → Stack／Docker 资源组织管理。

`docker-manager` 是暂名。当前处于开发前的需求与设计阶段：本目录有现行文档、原始讨论和历史归档，没有应用代码、构建配置、运行服务或 Git 仓库，尚无可安装的产品。

## 主要能力与边界

- 在 Web 中创建、查看、编辑 Compose、环境及附属运行配置，保存和部署分别反馈，无需先 SSH 到服务器建文件。
- 管理内外网独立节点、Stack、容器、镜像、网络和卷，提供分组标签与多用户的节点／操作权限。
- Copy 建立来源不变的独立配置，Apply 部署明确版本；Node Cross 表示部署位置迁移，执行后验证，通过后由用户选择是否删除来源。
- 提供 docker run 转 Compose 的文本转换工具，结果可编辑并带入 Stack 流程，转换本身不执行命令或部署。

管理器遵循原生 Docker／Compose 行为，不擅自注入额外网络或卷；不提供镜像构建、Dockerfile 和构建上下文管理。节点独立，不做自动调度。通常约 20 节点作为设计和验证基线，不设置固定 20 节点上限；实际容量未验证。

希望迁移按需携带存储，前期允许手动搬运；具体存储机制仍暂缓。迁移切换、中断和回退策略也需要继续确定，不能把配置复制说成完整迁移。UI 布局与视觉随功能实现细化。

## 组成与技术状态

逻辑上由 Web、Manager 和节点 Agent 组成，Agent 主动连接 Manager 已经确认。Manager 集中配置与协调、不可变配置版本和执行账本等属于本轮设计提案，尚待审阅及原型验证。语言、框架、数据库、通道协议和部署产物尚未选择。

当前优先考虑 Unix-like 下具备可用 Docker CLI／Compose 时的一致操作行为；Linux、FreeBSD 等环境意向不代表已经完成平台兼容验证。实际 Agent 环境、Docker 端点和文件路径组合会在实现前验证。

## 开始阅读

| 阅读任务 | 入口与主要内容 |
| --- | --- |
| 看这套文档如何安排 | [项目文档规划](docs/documentation-plan.md)：各篇职责、主骨架、参考、展开深度及检查记录 |
| 审阅产品目标与范围 | [需求规格](docs/requirements.md)：R01—R17、Q01—Q11、术语、使用场景和边界 |
| 核对日常操作方式 | [功能与交互设计](docs/functional-design.md)：编辑部署、跨节点、权限和转换流程 |
| 理解整体及模块 | [架构设计](docs/architecture.md) → [Manager](docs/components/manager.md)、[Agent](docs/components/agent.md)、[Web](docs/components/web.md) |
| 查精确定义 | [数据设计](docs/data-design.md)、[接口规格](docs/api-design.md)：逻辑实体、操作、状态和失败边界 |
| 安排实现与验证 | [开发实施计划](docs/development-plan.md)、[测试计划](docs/test-plan.md)：切片依赖、工程接入和可观察断言 |
| 准备安装和维护 | [部署与运行准备](docs/operations.md)：网络与权限、备份恢复、升级与故障，尚非可执行安装教程 |
| 查决定与剩余问题 | [决策与待办](docs/decisions.md)：用户确认、设计提案、阻塞范围及解决时点 |

文档以 req42／arc42 为统一骨架，模块、数据、接口、测试和运行继续承接需求与设计。现行稿是可审阅初稿，支持产品与方案讨论；物理协议、存储实现和迁移策略等未决项落实前，不作为可直接编码或部署的完整规格。文档检查与软件测试分别报告。

## 继续开发

先审阅当前需求、关键行为和技术提案，再决定技术组合及首个切片。建议从节点接入 → Web 保存配置 → 原生部署 → 查看结果形成完整流程，并尽早验证授权、原生语义和断线核对。当前没有可运行命令、安装镜像或开发依赖清单。

新决定记录于 decisions，再同步需求、设计、接口和测试。已有历史材料中的助手建议不会因为再次引用而变成用户已确认决定。正式名称、许可证、发布方式及首版完整范围仍需确定。

## 历史资料

[原始对话](docs/ChatGPT-Docker管理程序推荐-20261030-0119.md)与[早期讨论摘要](docs/conversation-notes.md)保留不变。后续产品决定的直接来源见 [11 月会话记录](archive/2026-11-03-session-deliverables/conversation/conversation.md)。

[2026-11-01 归档](archive/2026-11-01-documentation/README.md)和[2026-11-03 归档](archive/2026-11-03-session-deliverables/README.md)为历史快照，其“当前”“完成”等表述只对应当时。现行入口为本 README，归档中的设计稿不是额外的一套有效规格。
